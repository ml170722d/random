
# eco-patrol-ui

Dodao sam tab ikonicu da umesto podrazumevane stoji logo tima.
Dodao sam About Us stranicu i povezao je sa glavnom stranicom.

